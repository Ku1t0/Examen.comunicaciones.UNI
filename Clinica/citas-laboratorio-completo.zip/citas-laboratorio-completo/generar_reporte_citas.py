#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genera un reporte administrativo CSV y un resumen de estados."""

from __future__ import annotations

import csv
import os
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

AGI_DIR = Path(os.environ.get("CITAS_BASE_DIR", "/var/lib/asterisk/agi-bin"))
sys.path.insert(0, str(AGI_DIR))

from citas_common import leer_citas

REPORTE_CSV = Path(
    os.environ.get(
        "REPORTE_CSV",
        str(AGI_DIR / "reporte_administrativo.csv"),
    )
)
RESUMEN_TXT = Path(
    os.environ.get(
        "RESUMEN_TXT",
        str(AGI_DIR / "reporte_resumen.txt"),
    )
)

CAMPOS = [
    "id",
    "paciente",
    "anexo",
    "destino",
    "especialidad",
    "fecha",
    "hora",
    "estado",
    "intentos",
    "ultima_llamada",
    "ultima_respuesta",
]


def main() -> None:
    filas, _ = leer_citas()
    REPORTE_CSV.parent.mkdir(parents=True, exist_ok=True)

    with REPORTE_CSV.open("w", newline="", encoding="utf-8") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=CAMPOS)
        escritor.writeheader()
        for fila in filas:
            escritor.writerow({campo: fila.get(campo, "") for campo in CAMPOS})

    conteo = Counter((fila.get("estado") or "pendiente") for fila in filas)
    lineas = [
        "REPORTE ADMINISTRATIVO - CLÍNICA SALUD INTEGRAL",
        f"Generado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Total de citas: {len(filas)}",
        f"Pendientes: {conteo.get('pendiente', 0)}",
        f"Confirmadas: {conteo.get('confirmada', 0)}",
        f"Canceladas: {conteo.get('cancelada', 0)}",
        (
            "Reprogramación solicitada: "
            f"{conteo.get('reprogramacion_solicitada', 0)}"
        ),
        f"Sin respuesta: {conteo.get('sin_respuesta', 0)}",
    ]
    RESUMEN_TXT.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print("\n".join(lineas))


if __name__ == "__main__":
    main()
