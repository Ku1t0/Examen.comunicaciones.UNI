#!/bin/bash
set -euo pipefail

if [ "$#" -lt 2 ]; then
  echo "Uso: sudo $0 nombre_archivo \"Texto que debe decir\""
  exit 1
fi

NOMBRE="$1"
TEXTO="$2"
TMP_WAV="$(mktemp --suffix=.wav)"
TMP_8K="$(mktemp --suffix=.wav)"
trap 'rm -f "$TMP_WAV" "$TMP_8K"' EXIT

apt-get update -qq
apt-get install -y espeak-ng ffmpeg >/dev/null

espeak-ng -v es -s 145 -w "$TMP_WAV" "$TEXTO"
ffmpeg -y -i "$TMP_WAV" -ar 8000 -ac 1 -c:a pcm_s16le "$TMP_8K" \
  >/dev/null 2>&1

for idioma in en es es_419; do
  destino="/var/lib/asterisk/sounds/$idioma/custom"
  mkdir -p "$destino"
  install -o asterisk -g asterisk -m 0644 "$TMP_8K" "$destino/$NOMBRE.wav"
done

echo "Audio instalado como custom/$NOMBRE en en, es y es_419."
