#!/bin/bash
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Ejecuta: sudo bash install_complemento.sh"
  exit 1
fi

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGI_DIR="/var/lib/asterisk/agi-bin"
MARCA="$(date +%Y%m%d_%H%M%S)"

echo "==> Respaldando archivos actuales..."
mkdir -p /opt/backups/citas
for archivo in confirmar_cita.agi citas.csv resultados.csv; do
  if [ -f "$AGI_DIR/$archivo" ]; then
    cp -a "$AGI_DIR/$archivo" "/opt/backups/citas/${archivo}.${MARCA}"
  fi
done

echo "==> Instalando scripts..."
install -o asterisk -g asterisk -m 0640 "$DIR/citas_common.py" "$AGI_DIR/citas_common.py"
install -o asterisk -g asterisk -m 0750 "$DIR/confirmar_cita_v2.agi" "$AGI_DIR/confirmar_cita_v2.agi"
install -o root -g root -m 0755 "$DIR/programar_citas.py" /usr/local/bin/programar_citas.py
install -o root -g root -m 0755 "$DIR/generar_reporte_citas.py" /usr/local/bin/generar_reporte_citas.py
install -o root -g root -m 0755 "$DIR/migrar_citas.py" /usr/local/bin/migrar_citas.py
install -o root -g root -m 0755 "$DIR/crear_audio_asterisk.sh" /usr/local/bin/crear_audio_asterisk.sh
install -o root -g root -m 0755 "$DIR/backup_citas.sh" /usr/local/sbin/backup_citas.sh

echo "==> Migrando citas.csv..."
/usr/bin/python3 /usr/local/bin/migrar_citas.py
chown asterisk:asterisk "$AGI_DIR/citas.csv"
chmod 0660 "$AGI_DIR/citas.csv"
touch "$AGI_DIR/citas.csv.lock" "$AGI_DIR/resultados.csv.lock"
chown asterisk:asterisk "$AGI_DIR/citas.csv.lock" "$AGI_DIR/resultados.csv.lock"
chmod 0660 "$AGI_DIR/citas.csv.lock" "$AGI_DIR/resultados.csv.lock"

echo "==> Instalando timers y rotación de logs..."
install -o root -g root -m 0644 "$DIR/programar-citas.service" /etc/systemd/system/
install -o root -g root -m 0644 "$DIR/programar-citas.timer" /etc/systemd/system/
install -o root -g root -m 0644 "$DIR/generar-reporte-citas.service" /etc/systemd/system/
install -o root -g root -m 0644 "$DIR/generar-reporte-citas.timer" /etc/systemd/system/
install -o root -g root -m 0644 "$DIR/backup-citas.service" /etc/systemd/system/
install -o root -g root -m 0644 "$DIR/backup-citas.timer" /etc/systemd/system/
install -o root -g root -m 0644 "$DIR/citas-logrotate" /etc/logrotate.d/citas-asterisk

systemctl daemon-reload

echo
echo "Instalación de scripts terminada."
echo "AÚN DEBES:"
echo "1) Ajustar citas.csv."
echo "2) Reemplazar el dialplan con extensions_custom.conf.snippet."
echo "3) Recargar Asterisk."
echo "4) Probar una llamada forzada."
echo "5) Habilitar los timers cuando la prueba funcione."
