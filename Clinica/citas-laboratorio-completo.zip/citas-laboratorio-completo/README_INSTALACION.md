# Complemento del sistema de confirmación de citas

Este paquete amplía el laboratorio original con:

- llamada saliente automática mediante archivos `.call`;
- revisión periódica con `systemd timer`;
- tres intentos aproximados: 48 h, 24 h y 6 h antes, separados por al menos 4 horas;
- actualización de `citas.csv`;
- estados `confirmada`, `cancelada`, `reprogramacion_solicitada` y `sin_respuesta`;
- reporte administrativo;
- respaldo diario y rotación de logs.

## Importante

`PJSIP/1001` llama al softphone registrado como extensión 1001.

Para llamar a un teléfono móvil real necesitas un **trunk SIP** y una ruta saliente.
Después debes usar en `destino`:

```
Local/569XXXXXXXX@from-internal/n
```

El número debe tener el formato exigido por tu proveedor y la ruta saliente de FreePBX.

## Instalación rápida

```bash
unzip citas-laboratorio-completo.zip
cd citas-laboratorio-completo
sudo timedatectl set-timezone America/Santiago
sudo bash install_complemento.sh
```

Editar las citas:

```bash
sudo nano /var/lib/asterisk/agi-bin/citas.csv
```

Ejemplo para softphone:

```csv
id,anexo,destino,paciente,audio_paciente,especialidad,fecha,hora,audio_especialidad,estado,intentos,ultima_llamada,ultima_respuesta
CITA-001,1001,PJSIP/1001,Francisco Espinoza,custom/paciente_francisco,Cardiologia,2026-07-17,10:00,custom/esp_cardiologia,pendiente,0,,
```

Crear audios locales:

```bash
sudo crear_audio_asterisk.sh paciente_francisco "Hola Francisco Espinoza."
sudo crear_audio_asterisk.sh reprogramacion_solicitada \
  "Su solicitud de reprogramación fue registrada. El personal administrativo se comunicará con usted."
```

Editar el dialplan:

```bash
sudo nano /etc/asterisk/extensions_custom.conf
```

Usa el contenido de `extensions_custom.conf.snippet`, reemplazando el contexto anterior.
No dejes dos definiciones distintas de la extensión 7000.

Recargar:

```bash
sudo asterisk -rx "dialplan reload"
sudo asterisk -rx "dialplan show confirmacion-citas"
sudo asterisk -rx "dialplan show 7000@from-internal-custom"
```

Validar sintaxis:

```bash
sudo python3 -m py_compile \
  /var/lib/asterisk/agi-bin/citas_common.py \
  /var/lib/asterisk/agi-bin/confirmar_cita_v2.agi \
  /usr/local/bin/programar_citas.py \
  /usr/local/bin/generar_reporte_citas.py
```

Prueba manual marcando `7000`.

Prueba automática inmediata:

```bash
sudo python3 /usr/local/bin/programar_citas.py --force CITA-001
```

El softphone 1001 debe recibir la llamada.

Revisar:

```bash
sudo tail -f /var/log/asterisk/programar_citas.log
sudo tail -f /var/log/asterisk/confirmar_cita.log
sudo cat /var/lib/asterisk/agi-bin/citas.csv
sudo cat /var/lib/asterisk/agi-bin/resultados.csv
```

Generar reporte:

```bash
sudo -u asterisk python3 /usr/local/bin/generar_reporte_citas.py
sudo cat /var/lib/asterisk/agi-bin/reporte_resumen.txt
```

Habilitar automatización:

```bash
sudo systemctl enable --now programar-citas.timer
sudo systemctl enable --now generar-reporte-citas.timer
sudo systemctl enable --now backup-citas.timer
systemctl list-timers --all | grep citas
```

## Reiniciar una cita para nuevas pruebas

Edita la fila y deja:

```
estado=pendiente
intentos=0
ultima_llamada=
ultima_respuesta=
```

## Seguridad necesaria

1. Configura la hora:
   `sudo timedatectl set-timezone America/Santiago`.
2. En FreePBX crea/selecciona un certificado.
3. Habilita el transporte PJSIP TLS en el puerto TCP 5061.
4. En la extensión selecciona TLS y cifrado SRTP.
5. Configura el softphone con TLS y SRTP.
6. En AWS permite:
   - TCP 22 solo desde tu IP;
   - TCP 443 solo desde redes administrativas;
   - TCP 5061 desde clientes o proveedor autorizados;
   - UDP 10000-20000 desde clientes o proveedor autorizados.
7. Cuando TLS funcione, elimina o restringe UDP 5060.
8. Usa HTTPS en el panel FreePBX.
9. Mantén `citas.csv` y los logs con permisos restrictivos.
