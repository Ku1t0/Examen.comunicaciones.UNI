#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Funciones compartidas para el sistema de confirmación de citas."""

from __future__ import annotations

import csv
import fcntl
import os
import tempfile
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

BASE_DIR = Path(os.environ.get("CITAS_BASE_DIR", "/var/lib/asterisk/agi-bin"))
CITAS_CSV = Path(os.environ.get("CITAS_CSV", str(BASE_DIR / "citas.csv")))
RESULTADOS_CSV = Path(
    os.environ.get("RESULTADOS_CSV", str(BASE_DIR / "resultados.csv"))
)
CITAS_LOCK = Path(f"{CITAS_CSV}.lock")
RESULTADOS_LOCK = Path(f"{RESULTADOS_CSV}.lock")

DEFAULT_FIELDS = [
    "id",
    "anexo",
    "destino",
    "paciente",
    "audio_paciente",
    "especialidad",
    "fecha",
    "hora",
    "audio_especialidad",
    "estado",
    "intentos",
    "ultima_llamada",
    "ultima_respuesta",
]


@contextmanager
def archivo_bloqueado(path: Path, exclusive: bool):
    """Bloquea un archivo auxiliar para evitar escrituras concurrentes."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+", encoding="utf-8") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def _leer_sin_lock() -> tuple[list[dict[str, str]], list[str]]:
    if not CITAS_CSV.exists():
        raise FileNotFoundError(f"No existe {CITAS_CSV}")

    with CITAS_CSV.open(newline="", encoding="utf-8-sig") as archivo:
        lector = csv.DictReader(archivo)
        if lector.fieldnames is None:
            raise ValueError(f"{CITAS_CSV} no contiene encabezado")
        filas = [{k: (v or "").strip() for k, v in fila.items()} for fila in lector]
        return filas, list(lector.fieldnames)


def leer_citas() -> tuple[list[dict[str, str]], list[str]]:
    with archivo_bloqueado(CITAS_LOCK, exclusive=False):
        return _leer_sin_lock()


def _campos_completos(campos: Iterable[str], filas: Iterable[dict[str, str]]) -> list[str]:
    salida = list(campos)
    for obligatorio in DEFAULT_FIELDS:
        if obligatorio not in salida:
            salida.append(obligatorio)
    for fila in filas:
        for clave in fila:
            if clave not in salida:
                salida.append(clave)
    return salida


def _guardar_sin_lock(filas: list[dict[str, str]], campos: list[str]) -> None:
    CITAS_CSV.parent.mkdir(parents=True, exist_ok=True)
    campos = _campos_completos(campos, filas)

    stat_original = CITAS_CSV.stat() if CITAS_CSV.exists() else None
    fd, temporal = tempfile.mkstemp(
        prefix=f".{CITAS_CSV.name}.",
        suffix=".tmp",
        dir=str(CITAS_CSV.parent),
        text=True,
    )
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=campos, extrasaction="ignore")
            escritor.writeheader()
            for fila in filas:
                escritor.writerow({campo: fila.get(campo, "") for campo in campos})
            archivo.flush()
            os.fsync(archivo.fileno())

        if stat_original:
            os.chmod(temporal, stat_original.st_mode & 0o777)
            try:
                os.chown(temporal, stat_original.st_uid, stat_original.st_gid)
            except PermissionError:
                pass
        else:
            os.chmod(temporal, 0o660)

        os.replace(temporal, CITAS_CSV)
    finally:
        if os.path.exists(temporal):
            os.unlink(temporal)


def modificar_citas(
    mutador: Callable[[list[dict[str, str]], list[str]], bool]
) -> bool:
    """Ejecuta un cambio atómico. El mutador devuelve True si hubo cambios."""
    with archivo_bloqueado(CITAS_LOCK, exclusive=True):
        filas, campos = _leer_sin_lock()
        cambiado = bool(mutador(filas, campos))
        if cambiado:
            _guardar_sin_lock(filas, campos)
        return cambiado


def coincide(fila: dict[str, str], identificador: str) -> bool:
    return fila.get("id") == identificador or fila.get("anexo") == identificador


def buscar_cita(identificador: str) -> dict[str, str] | None:
    filas, _ = leer_citas()
    for fila in filas:
        if coincide(fila, str(identificador)):
            return fila
    return None


def actualizar_cita(identificador: str, **cambios: str) -> bool:
    def mutador(filas: list[dict[str, str]], campos: list[str]) -> bool:
        for clave in cambios:
            if clave not in campos:
                campos.append(clave)
        for fila in filas:
            if coincide(fila, str(identificador)):
                for clave, valor in cambios.items():
                    fila[clave] = "" if valor is None else str(valor)
                return True
        return False

    return modificar_citas(mutador)


def append_resultado(cabecera: list[str], valores: dict[str, str]) -> None:
    RESULTADOS_CSV.parent.mkdir(parents=True, exist_ok=True)
    with archivo_bloqueado(RESULTADOS_LOCK, exclusive=True):
        nuevo = not RESULTADOS_CSV.exists() or RESULTADOS_CSV.stat().st_size == 0
        with RESULTADOS_CSV.open("a", newline="", encoding="utf-8") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=cabecera, extrasaction="ignore")
            if nuevo:
                escritor.writeheader()
            escritor.writerow({campo: valores.get(campo, "") for campo in cabecera})
            archivo.flush()
            os.fsync(archivo.fileno())


def ahora_texto() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
