#!/bin/bash
set -euo pipefail

ORIGEN="/var/lib/asterisk/agi-bin"
DESTINO="/opt/backups/citas"
FECHA="$(date +%Y%m%d_%H%M%S)"

mkdir -p "$DESTINO"
tar -czf "$DESTINO/citas_$FECHA.tar.gz" \
  "$ORIGEN/citas.csv" \
  "$ORIGEN/resultados.csv" \
  "$ORIGEN/reporte_administrativo.csv" \
  "$ORIGEN/reporte_resumen.txt" 2>/dev/null || true

find "$DESTINO" -type f -name 'citas_*.tar.gz' -mtime +30 -delete
