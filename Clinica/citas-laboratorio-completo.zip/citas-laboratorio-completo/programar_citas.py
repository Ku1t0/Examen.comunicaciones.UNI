#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Programa llamadas automáticas de citas mediante archivos .call de Asterisk."""

from __future__ import annotations

import argparse
import fcntl
import logging
import os
import pwd
import grp
import re
import shutil
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

AGI_DIR = Path(os.environ.get("CITAS_BASE_DIR", "/var/lib/asterisk/agi-bin"))
sys.path.insert(0, str(AGI_DIR))

from citas_common import ahora_texto, modificar_citas

OUTGOING_DIR = Path(
    os.environ.get("ASTERISK_OUTGOING_DIR", "/var/spool/asterisk/outgoing")
)
LOCK_PATH = Path(
    os.environ.get("PROGRAMADOR_LOCK", "/var/lock/programar_citas.lock")
)
LOG_PATH = os.environ.get(
    "PROGRAMADOR_LOG", "/var/log/asterisk/programar_citas.log"
)
CALLER_ID = os.environ.get(
    "CITAS_CALLER_ID", "Clinica Salud Integral <7000>"
)
MAX_INTENTOS = 3
ESPERA_FINAL_MINUTOS = 45
MIN_HORAS_ENTRE_INTENTOS = 4
ESTADOS_FINALES = {
    "confirmada",
    "cancelada",
    "reprogramacion_solicitada",
    "sin_respuesta",
}


def configurar_log() -> logging.Logger:
    logging.basicConfig(
        filename=LOG_PATH,
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    return logging.getLogger("programar_citas")


def parsear_fecha_hora(fila: dict[str, str]) -> datetime:
    return datetime.strptime(
        f"{fila.get('fecha', '')} {fila.get('hora', '')}",
        "%Y-%m-%d %H:%M",
    )


def parsear_timestamp(valor: str) -> datetime | None:
    if not valor:
        return None
    try:
        return datetime.strptime(valor, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def entero(valor: str | None) -> int:
    try:
        return int(valor or 0)
    except (TypeError, ValueError):
        return 0


def intento_corresponde(intentos: int, horas_restantes: float) -> bool:
    """0: dentro de 48 h; 1: dentro de 24 h; 2: dentro de 6 h."""
    if horas_restantes <= 0:
        return False
    if intentos == 0:
        return horas_restantes <= 48
    if intentos == 1:
        return horas_restantes <= 24
    if intentos == 2:
        return horas_restantes <= 6
    return False


def nombre_seguro(valor: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", valor)[:80]


def crear_call_file(fila: dict[str, str], intento: int, dry_run: bool) -> Path | None:
    identificador = fila.get("id") or fila.get("anexo")
    destino = fila.get("destino", "").strip()
    if not destino:
        anexo = fila.get("anexo", "").strip()
        if not anexo:
            raise ValueError("La cita no tiene destino ni anexo")
        destino = f"PJSIP/{anexo}"

    contenido = "\n".join(
        [
            f"Channel: {destino}",
            f"CallerID: {CALLER_ID}",
            "MaxRetries: 0",
            "RetryTime: 60",
            "WaitTime: 30",
            "Context: confirmacion-citas",
            "Extension: s",
            "Priority: 1",
            f"Setvar: CITA_ID={identificador}",
            f"Setvar: CITA_INTENTO={intento}",
            "Archive: yes",
            "",
        ]
    )

    if dry_run:
        print(contenido)
        return None

    if not OUTGOING_DIR.is_dir():
        raise FileNotFoundError(f"No existe {OUTGOING_DIR}")

    fd, temporal = tempfile.mkstemp(prefix="cita_", suffix=".call", dir="/tmp", text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as archivo:
            archivo.write(contenido)
            archivo.flush()
            os.fsync(archivo.fileno())

        try:
            uid = pwd.getpwnam("asterisk").pw_uid
            gid = grp.getgrnam("asterisk").gr_gid
            os.chown(temporal, uid, gid)
        except KeyError:
            pass

        os.chmod(temporal, 0o640)
        destino_final = OUTGOING_DIR / (
            f"cita_{nombre_seguro(identificador)}_"
            f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.call"
        )
        shutil.move(temporal, destino_final)
        return destino_final
    finally:
        if os.path.exists(temporal):
            os.unlink(temporal)


def ejecutar(force_id: str | None, dry_run: bool, log: logging.Logger) -> None:
    ahora = datetime.now()

    def mutador(filas: list[dict[str, str]], campos: list[str]) -> bool:
        cambiado = False
        for campo in ("estado", "intentos", "ultima_llamada", "ultima_respuesta"):
            if campo not in campos:
                campos.append(campo)

        for fila in filas:
            identificador = fila.get("id") or fila.get("anexo", "")
            if force_id and force_id not in {fila.get("id"), fila.get("anexo")}:
                continue

            estado = (fila.get("estado") or "pendiente").strip().lower()
            if estado in ESTADOS_FINALES:
                if force_id:
                    log.warning("La cita %s ya está en estado final: %s", identificador, estado)
                continue

            intentos = entero(fila.get("intentos"))
            ultima_llamada = parsear_timestamp(fila.get("ultima_llamada", ""))

            if (
                intentos >= MAX_INTENTOS
                and ultima_llamada
                and ahora - ultima_llamada >= timedelta(minutes=ESPERA_FINAL_MINUTOS)
            ):
                fila["estado"] = "sin_respuesta"
                cambiado = True
                log.info("Cita %s marcada como sin_respuesta", identificador)
                continue

            try:
                fecha_cita = parsear_fecha_hora(fila)
            except ValueError as error:
                log.error("Cita %s con fecha/hora inválida: %s", identificador, error)
                continue

            horas_restantes = (fecha_cita - ahora).total_seconds() / 3600
            corresponde = bool(force_id) or intento_corresponde(intentos, horas_restantes)
            if not corresponde or intentos >= MAX_INTENTOS:
                continue

            # Evita duplicados y llamadas demasiado seguidas.
            if not force_id and ultima_llamada:
                tiempo_desde_ultima = ahora - ultima_llamada
                if tiempo_desde_ultima < timedelta(hours=MIN_HORAS_ENTRE_INTENTOS):
                    continue

            numero_intento = intentos + 1
            try:
                archivo = crear_call_file(fila, numero_intento, dry_run)
            except Exception as error:
                log.exception("No se pudo crear llamada para %s: %s", identificador, error)
                continue

            if dry_run:
                log.info("[DRY RUN] Cita %s intento %d", identificador, numero_intento)
                continue

            fila["intentos"] = str(numero_intento)
            fila["ultima_llamada"] = ahora_texto()
            fila["estado"] = "pendiente"
            cambiado = True
            log.info(
                "Llamada programada: cita=%s intento=%d archivo=%s",
                identificador,
                numero_intento,
                archivo,
            )

        return cambiado

    modificar_citas(mutador)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--force",
        metavar="ID_O_ANEXO",
        help="Programa una llamada inmediata para probar una cita pendiente.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Muestra el .call, pero no lo coloca en outgoing.",
    )
    args = parser.parse_args()

    log = configurar_log()
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with LOCK_PATH.open("a+", encoding="utf-8") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            log.info("Ya existe otra ejecución del programador.")
            return
        ejecutar(args.force, args.dry_run, log)


if __name__ == "__main__":
    main()
