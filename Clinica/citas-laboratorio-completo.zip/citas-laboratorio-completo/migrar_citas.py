#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Migra el citas.csv original del repositorio al esquema ampliado."""

from __future__ import annotations

import csv
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

CITAS = Path(
    os.environ.get("CITAS_CSV", "/var/lib/asterisk/agi-bin/citas.csv")
)
CAMPOS = [
    "id",
    "anexo",
    "destino",
    "paciente",
    "audio_paciente",
    "especialidad",
    "fecha",
    "hora",
    "audio_especialidad",
    "estado",
    "intentos",
    "ultima_llamada",
    "ultima_respuesta",
]


def main() -> None:
    if not CITAS.exists():
        print(f"ERROR: no existe {CITAS}", file=sys.stderr)
        sys.exit(1)

    with CITAS.open(newline="", encoding="utf-8-sig") as archivo:
        lector = csv.DictReader(archivo)
        filas = list(lector)
        campos_actuales = lector.fieldnames or []

    if all(campo in campos_actuales for campo in CAMPOS):
        print("citas.csv ya utiliza el esquema ampliado.")
        return

    marca = datetime.now().strftime("%Y%m%d_%H%M%S")
    respaldo = CITAS.with_name(f"{CITAS.name}.backup_{marca}")
    shutil.copy2(CITAS, respaldo)

    nuevas = []
    for indice, fila in enumerate(filas, start=1):
        anexo = (fila.get("anexo") or "").strip()
        nuevas.append(
            {
                "id": fila.get("id") or f"CITA-{indice:03d}",
                "anexo": anexo,
                "destino": fila.get("destino") or (f"PJSIP/{anexo}" if anexo else ""),
                "paciente": fila.get("paciente", ""),
                "audio_paciente": fila.get("audio_paciente", ""),
                "especialidad": fila.get("especialidad", ""),
                "fecha": fila.get("fecha", ""),
                "hora": fila.get("hora", ""),
                "audio_especialidad": fila.get("audio_especialidad", ""),
                "estado": fila.get("estado") or "pendiente",
                "intentos": fila.get("intentos") or "0",
                "ultima_llamada": fila.get("ultima_llamada", ""),
                "ultima_respuesta": fila.get("ultima_respuesta", ""),
            }
        )

    with CITAS.open("w", newline="", encoding="utf-8") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=CAMPOS)
        escritor.writeheader()
        escritor.writerows(nuevas)

    print(f"Migración completada. Respaldo: {respaldo}")


if __name__ == "__main__":
    main()
